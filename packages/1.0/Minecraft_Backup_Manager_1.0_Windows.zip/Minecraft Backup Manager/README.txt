=========================================================================================================================================
					Minecraft Backup Manager
				-------------------------------
					Version: 1.0 (Dirt)
					Author: Daniel Luque (danielluque14@gmail.com) / @LuqueDaniel
					License: GPLv3
					Source: http://github.com/LuqueDaniel/Minecraft_backup
=========================================================================================================================================


Recomendations
-----------------------------------------------------------------------------------------
 - Create a direct access of "Minecraft Backup Manage.exe" in your desktop.

Libraries and more
-----------------------------------------------------------------------------------------
 This application contain python 2.7 and PyQt v4
 
 - Python 2.7 (http://python.org) [Licensed under PSF - http://docs.python.org/2/license.html]
 - PyQt v4 (http://riverbankcomputing.co.uk/software/pyqt/intro) [Licensed under GPL v3]
 
Special thanks to
-----------------------------------------------------------------------------------------
 - Caballero6x6 (@Caballero6x6) For testing application in Windows XP.

